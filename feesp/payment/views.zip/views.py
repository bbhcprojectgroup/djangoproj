from django.shortcuts import render

# Create your views here.
from django.contrib.auth import login
from django.shortcuts import render
from django.contrib.auth import authenticate, login as auth_login
from django.conf import settings
#from .models import Transaction
from .paytm import generate_checksum, verify_checksum
from django.views.decorators.csrf import csrf_exempt
from login.views import encrypt
from login.models import Account
from examfee.views import data_save
from .models import Transaction
from acdfee.views import saveacad, clgfee


def initiate_payment(request):
    """if request.method == "GET":
        return render(request, 'payments/pay.html')"""
    """try:
        username = request.POST['username']
        password = request.POST['password']
        amount = int(request.POST['amount'])
        if(Account.objects.filter(username=username).exists()):
                 user = Account.objects.get(username=username)

        if user is None:
            raise ValueError
        #auth_login(request=request, user=user)
    except:
            return render(request, 'payments/pay.html', context={'error': 'Wrong Accound Details or amount'})"""

   
    amount=request.POST['amt']
    global work
    work=request.POST['type']
    user=request.user
    #if (user.check_password(password)):
    transaction = Transaction.objects.create(made_by=user, amount=amount)
    transaction.save()
    merchant_key = settings.PAYTM_SECRET_KEY
    global usr
    usr=request.user
   
    params = (
        ('MID', settings.PAYTM_MERCHANT_ID),
        ('ORDER_ID', str(transaction.order_id)),
        ('CUST_ID', str(transaction.made_by.email)),
        ('TXN_AMOUNT', str(transaction.amount)),
        ('CHANNEL_ID', settings.PAYTM_CHANNEL_ID),
        ('WEBSITE', settings.PAYTM_WEBSITE),
        # ('EMAIL', request.user.email),
        # ('MOBILE_N0', '9911223388'),
        ('INDUSTRY_TYPE_ID', settings.PAYTM_INDUSTRY_TYPE_ID),
        ('CALLBACK_URL', 'http://127.0.0.1:8000/callback/'),
        # ('PAYMENT_MODE_ONLY', 'NO'),
    )

    paytm_params = dict(params)
    checksum = generate_checksum(paytm_params, merchant_key)

    transaction.checksum = checksum
    transaction.save()

    paytm_params['CHECKSUMHASH'] = checksum
    print('SENT: ', checksum)
    return render(request, 'payments/redirect.html', context=paytm_params)
    """else:
        return render(request, 'payments/pay.html', context={'error': 'Wrong Password'})"""

@csrf_exempt
def callback(request):
    if request.method == 'POST':
        received_data = dict(request.POST)
        paytm_params = {}
        paytm_checksum = received_data['CHECKSUMHASH'][0]
        for key, value in received_data.items():
            if key == 'CHECKSUMHASH':
                paytm_checksum = value[0]
            else:
                paytm_params[key] = str(value[0])
        # Verify checksum
        is_valid_checksum = verify_checksum(paytm_params, settings.PAYTM_SECRET_KEY, str(paytm_checksum))

        
        if(received_data['RESPMSG']==['Txn Success']):

            if(work=='examfee'):
                received_data['exam']='True'
                data_save(request)
                
            else:
                received_data['exam']='False'
                saveacad(request)
                
                print(":)")
        
        login(request, usr)
        print("logged in")

        print(request.user)
        if is_valid_checksum:
            received_data['message'] = "Checksum Matched"
        else:
            received_data['message'] = "Checksum Mismatched"
            return render(request, 'payments/callback.html', context=received_data)
        return render(request, 'payments/callback.html', context=received_data)

